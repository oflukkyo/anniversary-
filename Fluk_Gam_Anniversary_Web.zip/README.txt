FLUKE ♡ KAEM — 3RD ANNIVERSARY

เว็บตัวอย่างธีมครีม/แดงตามภาพอ้างอิง
- เปิดซองจดหมาย
- จดหมายครบรอบ
- Hero photo
- Photo collage
- ตัวนับจำนวนวันที่คบกัน
- ปุ่มเพลง

วิธีใช้บน iPad/iPhone:
1. สร้าง GitHub repository ชื่อ anniversary
2. อัปโหลด index.html
3. สร้างโฟลเดอร์ assets แล้วอัปโหลดรูป/เพลงของคุณ
4. เปิด GitHub Pages ใน Settings > Pages
5. เลือก Deploy from a branch > main > /(root) > Save
6. รอลิงก์เว็บ แล้วส่งให้แฟน

หมายเหตุ: เบราว์เซอร์มือถือมักไม่อนุญาต autoplay เพลง ดังนั้นเว็บจะเริ่มเพลงเมื่อผู้ใช้กดซอง/ปุ่มเพลง
